// *******************************************************************
// * relay-control-client.h
// *
// *
// * Copyright 2012 by Ember Corporation. All rights reserved.              *80*
// *******************************************************************

// Convenience method to send a set message to the server
void emberAfPluginRelayControlClientSendSetRelayState(EmberNodeId nodeId,
                                                      int8u srcEndpoint,
                                                      int8u dstEndpoint,
                                                      boolean isEnabled,
                                                      int32u magicNumber);

